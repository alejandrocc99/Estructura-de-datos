// EjemploHerencia.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include "Rectangulo.h"
#include "conio.h"
#include "Paralelogramo.h"

using namespace std;

int main(void) {
   Rectangulo Rect;
   Paralelogramo Par;
 
   Rect.setWidth(5);
   Rect.setHeight(7);

   Par.setWidth(3);
   Par.setHeight(8);
   

   // Muestra el �rea de un rectangulo
   cout << "Total area: " << Rect.getArea() << endl;
   cout<< "Area paralelogramo: "<<Par.getArea()<<endl;
   getch();
   return 0;
}